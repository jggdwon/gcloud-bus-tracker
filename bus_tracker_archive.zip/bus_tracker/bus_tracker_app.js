/**
 * Bus Tracker Application - Final Stable Version v13
 * Added 'Time at Stop' counter.
 */

// --- Application State & Config ---
const config = {
    boundingBox: '-3.574,50.690,-3.454,50.749',
    map: { center: [50.7195, -3.514], zoom: 13, maxZoom: 18 },
    zoomLevels: {
        busIcon: { small: 14, medium: 16 },
        busStopIcon: { small: 15, medium: 17 },
        busStopLayer: 15,
    },
    speedAvgSize: 5,
    atStopThreshold: 0.0186411, // miles, approx 30 meters
};

const appState = {
    buses: {},
    busStops: {},
    busStopMarkers: {},
    followedBus: null,
    map: null,
    busStopsLayer: L.layerGroup(),
    busMarkersLayer: L.markerClusterGroup(),
    routeLayer: L.layerGroup(),
    fetchIntervalId: null,
    heartbeatIntervalId: null,
    updateInterval: 2000,
    isPanningProgrammatically: false,
    stopListsCache: {}, // Cache for lineRef -> [stop names]
};

// --- DOM Elements ---
const ui = {};

// --- Map Initialization ---
function initMap() {
    appState.map = L.map('map', { maxZoom: config.map.maxZoom, zoomControl: false }).setView(config.map.center, config.map.zoom);
    appState.routeLayer.addTo(appState.map);
    appState.busMarkersLayer.addTo(appState.map);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(appState.map);
    appState.map.on('zoomend', handleMapZoom);
    appState.map.on('click', unfollowBus);
    appState.map.on('dragstart', unfollowBus);
    appState.map.on('zoomstart', unfollowBus);
    appState.map.on('keydown', unfollowBus);
    appState.map.on('popupopen', function(e) {
        appState.isPanningProgrammatically = true;
        var px = appState.map.project(e.popup._latlng); // find the pixel location on the map where the popup anchor is
        px.y -= e.popup._container.clientHeight/2; // find the height of the popup container, divide by 2, subtract from the Y axis
        appState.map.panTo(appState.map.unproject(px),{animate: true}); // pan to new center
        setTimeout(() => { appState.isPanningProgrammatically = false; }, 1200);

        // Fade-in logic
        const popupContainer = e.popup._container;
        popupContainer.style.opacity = 0;
        // Force a reflow before applying the transition
        void popupContainer.offsetWidth;
        popupContainer.style.transition = 'opacity 1.5s ease-in';
        popupContainer.style.opacity = 1;
    });

    appState.map.on('popupclose', function(e) {
        // Reset style so it doesn't interfere with next open
        if (e.popup && e.popup._container) {
            e.popup._container.style.transition = '';
        }
    });
}

// --- Helper Functions ---
const toRad = (deg) => deg * Math.PI / 180;
const getDistance = (lat1, lon1, lat2, lon2) => {
    const R = 3958.8; // miles
    const rlat1 = toRad(lat1), rlat2 = toRad(lat2);
    const dLat = rlat2 - rlat1, dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(rlat1) * Math.cos(rlat2) * Math.sin(dLon/2) * Math.sin(dLon/2);
    return 2 * R * Math.asin(Math.sqrt(a));
};

const toDegrees = (rad) => rad * 180 / Math.PI;

function calculateBearing(lat1, lon1, lat2, lon2) {
    const dLon = toRad(lon2 - lon1);
    const lat1Rad = toRad(lat1);
    const lat2Rad = toRad(lat2);
    const y = Math.sin(dLon) * Math.cos(lat2Rad);
    const x = Math.cos(lat1Rad) * Math.sin(lat2Rad) - Math.sin(lat1Rad) * Math.cos(lat2Rad) * Math.cos(dLon);
    return (toDegrees(Math.atan2(y, x)) + 360) % 360;
}

function predictPosition(lat, lon, bearing, speedMph, timeSeconds) {
    if (speedMph < 1 || bearing === null) {
        return { lat, lon };
    }
    const R = 3958.8; // Earth's radius in miles
    const distance = (speedMph * timeSeconds) / 3600; // distance in miles

    const latRad = toRad(lat);
    const lonRad = toRad(lon);
    const bearingRad = toRad(bearing);

    const lat2Rad = Math.asin(Math.sin(latRad) * Math.cos(distance / R) +
                           Math.cos(latRad) * Math.sin(distance / R) * Math.cos(bearingRad));
    const lon2Rad = lonRad + Math.atan2(Math.sin(bearingRad) * Math.sin(distance / R) * Math.cos(latRad),
                                     Math.cos(distance / R) - Math.sin(latRad) * Math.sin(lat2Rad));

    return { lat: toDegrees(lat2Rad), lon: toDegrees(lon2Rad) };
}

function getPointBehind(lat, lon, bearing, distanceMiles) {
    if (bearing === null) {
        return { lat, lon };
    }
    // To go backward, we add 180 degrees to the bearing.
    const reverseBearing = (bearing + 180) % 360;
    
    const R = 3958.8; // Earth's radius in miles

    const latRad = toRad(lat);
    const lonRad = toRad(lon);
    const bearingRad = toRad(reverseBearing);

    const lat2Rad = Math.asin(Math.sin(latRad) * Math.cos(distanceMiles / R) +
                           Math.cos(latRad) * Math.sin(distanceMiles / R) * Math.cos(bearingRad));
    const lon2Rad = lonRad + Math.atan2(Math.sin(bearingRad) * Math.sin(distanceMiles / R) * Math.cos(latRad),
                                     Math.cos(distanceMiles / R) - Math.sin(latRad) * Math.sin(lat2Rad));

    return { lat: toDegrees(lat2Rad), lon: toDegrees(lon2Rad) };
}

function findNearbyBusStop(busLat, busLon) {
    for (const stopCode in appState.busStops) {
        const stop = appState.busStops[stopCode];
        if (getDistance(busLat, busLon, stop.Latitude, stop.Longitude) < config.atStopThreshold) {
            return stop;
        }
    }
    return null;
}

function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = (hash << 5) - hash + char;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
}

function getColorFromLineRef(lineRef) {
    const hash = simpleHash(lineRef);
    const hue = Math.abs(hash % 360);
    return `hsl(${hue}, 70%, 50%)`;
}

async function fetchAndParseStopList(lineRef, directionRef) {
    const cacheKey = `${lineRef}_${directionRef}`;
    if (appState.stopListsCache[cacheKey]) {
        return appState.stopListsCache[cacheKey];
    }

    let debugLog = `--- Debug Log for ${lineRef} (${directionRef}) ---\n`;
    debugLog += `Cache key: ${cacheKey}\n`;

    try {
        debugLog += `Fetching /timetable-for-line?lineRef=${lineRef}\n`;
        const response = await fetch(`/timetable-for-line?lineRef=${lineRef}`);
        debugLog += `Response status: ${response.status}\n`;
        if (!response.ok) {
            throw new Error(`Failed to fetch timetable for line ${lineRef}`);
        }
        const xmlText = await response.text();
        debugLog += `XML received (first 100 chars): ${xmlText.substring(0, 100)}\n`;
        const xmlDoc = new DOMParser().parseFromString(xmlText, "text/xml");

        // 1. Create a map of all StopPoints
        const stopPoints = {};
        const stopPointNodes = xmlDoc.getElementsByTagName('StopPoint');
        debugLog += `Found ${stopPointNodes.length} <StopPoint> nodes.\n`;
        for (const node of stopPointNodes) {
            const stopPointRef = node.getElementsByTagName('AtcoCode')[0]?.textContent;
            const commonName = node.getElementsByTagName('CommonName')[0]?.textContent;
            const lat = node.getElementsByTagName('Latitude')[0]?.textContent;
            const lon = node.getElementsByTagName('Longitude')[0]?.textContent;
            if (stopPointRef && commonName && lat && lon) {
                stopPoints[stopPointRef] = { name: commonName, lat: parseFloat(lat), lon: parseFloat(lon) };
            }
        }
        debugLog += `Parsed ${Object.keys(stopPoints).length} unique stop points.\n`;

        // 2. Find the correct JourneyPattern
        let finalStopList = [];
        const services = xmlDoc.getElementsByTagName('Service');
        debugLog += `Found ${services.length} <Service> nodes.\n`;
        for (const service of services) {
            const serviceLineName = service.getElementsByTagName('LineName')[0]?.textContent;
            debugLog += `Checking service with LineName: ${serviceLineName}\n`;
            if (serviceLineName === lineRef) {
                debugLog += `  -> Match found!\n`;
                const journeyPatterns = service.getElementsByTagName('JourneyPattern');
                debugLog += `  Found ${journeyPatterns.length} <JourneyPattern> nodes.\n`;
                for (const jp of journeyPatterns) {
                    const jpDirection = jp.getElementsByTagName('Direction')[0]?.textContent?.toLowerCase();
                    debugLog += `  Checking journey pattern with Direction: ${jpDirection}\n`;
                    if (jpDirection === directionRef) {
                        debugLog += `    -> Match found!\n`;
                        const timingLinks = jp.getElementsByTagName('JourneyPatternTimingLink');
                        debugLog += `    Found ${timingLinks.length} <JourneyPatternTimingLink> nodes.\n`;
                        const stopRefs = [];
                        if (timingLinks.length > 0) {
                            const firstStopRef = timingLinks[0].getElementsByTagName('From')[0]?.getElementsByTagName('StopPointRef')[0]?.textContent;
                            if (firstStopRef) stopRefs.push(firstStopRef);
                            for (const link of timingLinks) {
                                const stopRef = link.getElementsByTagName('To')[0]?.getElementsByTagName('StopPointRef')[0]?.textContent;
                                if (stopRef) stopRefs.push(stopRef);
                            }
                        }
                        debugLog += `    Parsed ${stopRefs.length} stop references from links.\n`;
                        const namedStops = stopRefs.map(ref => stopPoints[ref]).filter(Boolean);
                        debugLog += `    Converted to ${namedStops.length} named stops.\n`;
                        if (namedStops.length > 0) {
                            finalStopList = namedStops;
                            break;
                        }
                    }
                }
            }
            if (finalStopList.length > 0) break;
        }
        
        debugLog += `Final parsed stop list count: ${finalStopList.length}\n`;
        if (finalStopList.length === 0) {
            throw new Error("Failed to parse any stops. See log for details.");
        }

        appState.stopListsCache[cacheKey] = finalStopList;
        return finalStopList;

    } catch (error) {
        console.error(`Error parsing stop list for line ${lineRef}:`, error);
        debugLog += `\n--- ERROR ---\n${error.name}: ${error.message}\n${error.stack}`;
        showErrorPopup({ name: `Debug Log for ${lineRef}`, message: '', stack: debugLog });
        appState.stopListsCache[cacheKey] = [];
        return [];
    }
}

function updateNextStopForBus(bus) {
    const directionRef = bus.directionRef;
    if (!directionRef) return;

    const cacheKey = `${bus.lineRef}_${directionRef}`;
    const stopList = appState.stopListsCache[cacheKey];

    if (!stopList || stopList.length === 0) {
        bus.nextStopName = null;
        return;
    }

    let closestStop = null;
    let minDistance = Infinity;

    const busLatLng = bus.marker.getLatLng();

    for (const stop of stopList) {
        const dist = getDistance(busLatLng.lat, busLatLng.lng, stop.lat, stop.lon);

        // Check if the stop is "ahead" of the bus
        const bearingToStop = calculateBearing(busLatLng.lat, busLatLng.lng, stop.lat, stop.lon);
        const bearingDiff = Math.abs(bus.bearing - bearingToStop);
        const isAhead = Math.min(bearingDiff, 360 - bearingDiff) < 90; // Check if it's within a 180-degree arc in front of the bus

        if (isAhead && dist < minDistance) {
            minDistance = dist;
            closestStop = stop;
        }
    }

    bus.nextStopName = closestStop ? closestStop.name : (stopList.length > 0 ? stopList[stopList.length - 1].name : null);
    console.log(`Bus ${bus.vehicleRef} next stop: ${bus.nextStopName}`);
}

// --- Icon & UI ---
const createIcon = (html, className, size) => L.divIcon({ html, className, iconSize: [size, size], iconAnchor: [size / 2, size / 2], popupAnchor: [0, -(size / 2) - 5] });

function createBusIcon(size, label, color, highlighted = false, isNearStop = false) {
    const gradient = `radial-gradient(circle, ${color} 0%, ${color} 50%, rgba(0,0,0,0) 70%)`;
    const style = `background: ${gradient}; opacity: 0.8;`;
    const html = `<div class="bus-icon-container" style="${style}"><i class="fa fa-bus"></i><span class="bus-label">${label}</span></div>`;
    return createIcon(html, `bus-icon size-${size} ${highlighted ? 'highlight' : ''} ${isNearStop ? 'nearby' : ''}`, size);
}

function getIconByZoom(type, zoom, label, highlighted = false, isNearStop = false) {
    const levels = config.zoomLevels[type === 'bus' ? 'busIcon' : 'busStopIcon'];
    if (type === 'bus') {
        const size = zoom < levels.small ? 40 : zoom < levels.medium ? 64 : 96;
        const color = getColorFromLineRef(label);
        return createBusIcon(size, label, color, highlighted, isNearStop);
    } else {
        const size = zoom < levels.small ? 20 : zoom < levels.medium ? 32 : 48;
        return createIcon('<i class="fa fa-dot-circle-o"></i>', `bus-stop-icon size-${size} ${highlighted ? 'highlight' : ''}`, size);
    }
}

function getSpeedColor(speed) {
    const clampedSpeed = Math.min(Math.max(speed, 0), 20); // Clamp speed between 0 and 20
    const hue = 39 + (120 - 39) * (clampedSpeed / 20); // Interpolate hue from orange (39) to green (120)
    return `hsl(${hue}, 100%, 50%)`;
}

function getCounterColor(seconds) {
    const clampedSeconds = Math.min(Math.max(seconds, 0), 60);
    const hue = 120 - (120 * (clampedSeconds / 60)); // 120 is green, 0 is red
    return `hsl(${hue}, 100%, 50%)`;
}

function updatePopupContent(bus, movementState = '', debugInfo = {}) {
    const isTracked = appState.followedBus === bus.itemIdentifier;
    let atStopText = '';
    if (bus.currentStopCode && appState.busStops[bus.currentStopCode]) {
        const stopName = appState.busStops[bus.currentStopCode].CommonName;
        const secondsAtStop = Math.round((Date.now() - bus.atStopSince) / 1000);
        atStopText = `<div class="at-stop-info"><b>At Stop:</b> ${stopName} <i class="fa fa-map-pin"></i><br><b>Time at stop:</b> ${secondsAtStop}s</div>`;
    }

    let indicatorClass = '';
    if (movementState === 'moved') indicatorClass = 'flash-green';
    if (movementState === 'stationary') indicatorClass = 'flash-red';
    
    const secondsSinceUpdate = Math.round((Date.now() - (bus.lastMovedTime || bus.lastPollTime)) / 1000);
    const displaySeconds = Math.min(secondsSinceUpdate, 999);
    const heartColor = getCounterColor(displaySeconds);
    const shadowStyle = `text-shadow: -1px -1px 0 ${heartColor}, 1px -1px 0 ${heartColor}, -1px 1px 0 ${heartColor}, 1px 1px 0 ${heartColor};`;

    const heartStyle = `--heart-color: ${heartColor}; background-color: ${indicatorClass ? 'inherit' : heartColor};`;

    const indicatorHTML = `<span class="update-heart ${indicatorClass}" style="${heartStyle}"><span class="heart-counter" style="${shadowStyle}">${displaySeconds}</span></span>`;

    const speedColor = getSpeedColor(bus.displaySpeed);
    const speedHTML = `<span class="speed-value" style="background-color: ${speedColor};">${bus.displaySpeed.toFixed(1)}</span> mph`;
    
    const bearing = bus.bearing !== null ? bus.bearing : 0;
    const compassHTML = `<div class="compass-container"><div class="north-indicator">N</div><div class="compass-needle" style="--bearing: ${bearing}deg;"></div></div>`;

    const topLineHTML = `<div class="top-line">${indicatorHTML} ${speedHTML} ${compassHTML}</div>`;
    
    const nextStopHTML = `<span style="color: #999;"><b>Next Stop:</b> (Temporarily disabled)</span><br>`;
    
    const content = `
        ${topLineHTML}
        ${atStopText}
        <b>Line:</b> ${bus.lineRef}<br>
        <b>Bus:</b> ${bus.vehicleRef}<br>
    `;
    bus.marker.getPopup().setContent(content);
}

function showErrorPopup(error) {
    const errorMessage = `${error.name}: ${error.message}\n\n${error.stack}`;
    ui.errorMessage.textContent = errorMessage;
    ui.errorOverlay.classList.remove('hidden');
}

// --- Event Handlers ---
function handleMapZoom() {
    const zoom = appState.map.getZoom();
    if (zoom >= config.zoomLevels.busStopLayer && ui.busStopToggle.checked) {
        if (!appState.map.hasLayer(appState.busStopsLayer)) appState.map.addLayer(appState.busStopsLayer);
    } else {
        if (appState.map.hasLayer(appState.busStopsLayer)) appState.map.removeLayer(appState.busStopsLayer);
    }
    for (const key in appState.buses) {
        const bus = appState.buses[key];
        bus.marker.setIcon(getIconByZoom('bus', zoom, bus.lineRef, appState.followedBus === key, bus.isNearStop));
    }
    appState.busStopsLayer.eachLayer(layer => layer.setIcon(getIconByZoom('stop', zoom)));
}

function unfollowBus() {
    if (appState.isPanningProgrammatically) {
        return;
    }
    if (appState.followedBus && appState.buses[appState.followedBus]) {
        const bus = appState.buses[appState.followedBus];
        bus.marker.setIcon(getIconByZoom('bus', appState.map.getZoom(), bus.lineRef, false, bus.isNearStop));
    }
    appState.followedBus = null;
}

function triggerDazzle(iconElement) {
    if (!iconElement || !iconElement.firstChild) return;
    const child = iconElement.firstChild;
    child.classList.remove('dazzle-child');
    void child.offsetWidth;
    child.classList.add('dazzle-child');
}

function handleBusClick(itemIdentifier, openPopupAfter = false) {
    if (appState.isPanningProgrammatically) return;

    const bus = appState.buses[itemIdentifier];
    if (!bus) return;

    unfollowBus();
    appState.followedBus = itemIdentifier;
    bus.marker.setIcon(getIconByZoom('bus', appState.map.getZoom(), bus.lineRef, true, bus.isNearStop));
    
    const targetMarker = bus.marker;
    const targetCenter = targetMarker.getLatLng();

    const arrivalSequence = () => {
        triggerDazzle(targetMarker._icon);
        if (openPopupAfter) {
            setTimeout(() => {
                if (targetMarker && !targetMarker.isPopupOpen()) {
                    targetMarker.openPopup();
                }
            }, 600);
        }
        appState.isPanningProgrammatically = false;
    };

    appState.isPanningProgrammatically = true;
    
    appState.map.flyTo(targetCenter, 18, {
        duration: 2.5 // A longer, smoother flight
    });
    appState.map.once('moveend', arrivalSequence);

    ui.sidebar.classList.remove('active');
}

function handleBusStopClick(stopCode, openPopupAfter = false) {
    if (appState.isPanningProgrammatically) return;

    const stopMarker = appState.busStopMarkers[stopCode];
    if (!stopMarker) return;

    if (!appState.map.hasLayer(appState.busStopsLayer)) {
        appState.map.addLayer(appState.busStopsLayer);
    }

    const targetCenter = stopMarker.getLatLng();
    
    if (appState.map.getCenter().distanceTo(targetCenter) < 10) {
        triggerDazzle(stopMarker._icon);
        if (openPopupAfter && !stopMarker.isPopupOpen()) {
            stopMarker.openPopup();
        }
        return;
    }

    appState.isPanningProgrammatically = true;
    appState.map.flyTo(targetCenter, 17, {
        duration: 1.5
    });

    appState.map.once('moveend', () => {
        triggerDazzle(stopMarker._icon);
        if (openPopupAfter) {
            setTimeout(() => {
                if (!stopMarker.isPopupOpen()) {
                    stopMarker.openPopup();
                }
            }, 600);
        }
        appState.isPanningProgrammatically = false;
    });
}

function handleListClick(event) {
    const target = event.target.closest('li');
    if (!target || !target.dataset.id) return;
    const { id, type } = target.dataset;
    if (type === 'bus') {
        handleBusClick(id, true);
    } else if (type === 'stop') {
        handleBusStopClick(id, true);
    }
    ui.sidebar.classList.remove('active');
}

// --- Data Fetching & Processing ---
async function fetchBusStops() {
    try {
        const response = await fetch('/bus-stops');
        if (!response.ok) throw new Error(`API error fetching bus stops: ${response.status} ${response.statusText}`);
        const data = await response.json();
        if (!data || !Array.isArray(data)) throw new Error('Received invalid data for bus stops.');
        if (data.length === 0) return;

        data.sort((a, b) => (a.CommonName || '').localeCompare(b.CommonName || ''));
        const fragment = document.createDocumentFragment();
        data.forEach(stop => {
            if (stop.ATCOCode && stop.Latitude && stop.Longitude) {
                appState.busStops[stop.ATCOCode] = stop;
                const marker = L.marker([stop.Latitude, stop.Longitude], { icon: getIconByZoom('stop', appState.map.getZoom()) }).addTo(appState.busStopsLayer);
                marker.bindPopup(`<b>${stop.CommonName}</b><br>${stop.Street}`);
                appState.busStopMarkers[stop.ATCOCode] = marker;
                const listItem = document.createElement('li');
                listItem.dataset.id = stop.ATCOCode;
                listItem.dataset.type = 'stop';
                listItem.innerHTML = stop.CommonName;
                fragment.appendChild(listItem);
            }
        });
        ui.busStopList.innerHTML = '';
        ui.busStopList.appendChild(fragment);
    } catch (error) {
        console.error(error);
        showErrorPopup(error);
    }
}

async function fetchData() {
    const pollTime = Date.now();
    try {
        const response = await fetch(`/api?boundingBox=${config.boundingBox}`);
        if (!response.ok) throw new Error(`API error: ${response.status} ${response.statusText}`);
        
        ui.statusMessage.textContent = '';
        const xmlDoc = new DOMParser().parseFromString(await response.text(), "text/xml");
        const vehicleActivities = Array.from(xmlDoc.getElementsByTagName("VehicleActivity"));
        const currentVehicleIds = new Set();

        vehicleActivities.forEach(va => {
            const mvj = va.getElementsByTagName("MonitoredVehicleJourney")[0];
            const recordedAtTime = new Date(va.getElementsByTagName("RecordedAtTime")[0].textContent);
            if (!mvj || isNaN(recordedAtTime.getTime())) return;

            const itemIdentifier = va.getElementsByTagName("ItemIdentifier")[0].textContent;
            currentVehicleIds.add(itemIdentifier);

            const newLat = parseFloat(mvj.getElementsByTagName("Latitude")[0].textContent);
            const newLon = parseFloat(mvj.getElementsByTagName("Longitude")[0].textContent);
            if (isNaN(newLat) || isNaN(newLon)) return;

            const bus = appState.buses[itemIdentifier];
            const nearbyStop = findNearbyBusStop(newLat, newLon);
            const lineRef = mvj.getElementsByTagName("LineRef")[0]?.textContent || 'N/A';

            if (bus) { // Existing bus
                const dist = getDistance(bus.lat, bus.lon, newLat, newLon);
                let movementState = 'stationary';
                const timeDiffSeconds = (recordedAtTime.getTime() - bus.lastUpdateTime) / 1000;
                
                if (dist > 0.005 && timeDiffSeconds > 0) { // ~8 meters, bus is moving
                    bus.stoppedUpdateCount = 0; // Reset the counter
                    movementState = 'moved';
                    bus.lastMovedTime = pollTime;
                    const timeDiffHours = timeDiffSeconds / 3600;
                    const currentSpeed = dist / timeDiffHours;
                    bus.speedHistory.push(currentSpeed);
                    if (bus.speedHistory.length > config.speedAvgSize) bus.speedHistory.shift();
                    bus.displaySpeed = bus.speedHistory.reduce((a, b) => a + b, 0) / bus.speedHistory.length;
                    
                    const bearingFromApi = mvj.getElementsByTagName("Bearing")[0]?.textContent;
                    if (bearingFromApi) {
                        bus.bearing = parseFloat(bearingFromApi);
                    } else {
                        bus.bearing = calculateBearing(bus.lat, bus.lon, newLat, newLon);
                    }

                    // Animate to the new, actual position over the exact time delta.
                    let duration = timeDiffSeconds * 1000;
                    if (bus.isAnimating) {
                        duration *= 0.9; // Increase speed by ~10% if already sliding
                    }

                    bus.isAnimating = true;
                    bus.marker.slideTo([newLat, newLon], {
                        duration: duration,
                        keepAtCenter: false,
                    });

                } else { // Bus is stationary or has very small GPS jitter
                    // We do nothing here. The 'slideend' event will handle setting speed to 0 when the animation finishes.
                }
                
                // ALWAYS update the internal state to the latest actual position
                bus.lat = newLat;
                bus.lon = newLon;
                bus.lastUpdateTime = recordedAtTime.getTime();
                bus.lastPollTime = pollTime;
                bus.isNearStop = !!nearbyStop;
                bus.directionRef = mvj.getElementsByTagName("DirectionRef")[0]?.textContent?.toLowerCase();

                updateNextStopForBus(bus);

                if (nearbyStop) {
                    if (bus.currentStopCode !== nearbyStop.ATCOCode) {
                        bus.atStopSince = Date.now();
                        bus.currentStopCode = nearbyStop.ATCOCode;
                    }
                } else {
                    bus.atStopSince = null;
                    bus.currentStopCode = null;
                }

                bus.marker.setIcon(getIconByZoom('bus', appState.map.getZoom(), bus.lineRef, appState.followedBus === itemIdentifier, bus.isNearStop));
                if (appState.followedBus === itemIdentifier) {
                    // Gently pan the map to keep the bus in view, but don't force center
                    appState.map.panTo([newLat, newLon], { animate: true, duration: 1.0 });
                }
                updatePopupContent(bus, movementState, { distance: dist });
            } else { // New bus
                const bearingFromApi = mvj.getElementsByTagName("Bearing")[0]?.textContent;
                const bearing = bearingFromApi ? parseFloat(bearingFromApi) : null;

                const marker = L.marker([newLat, newLon], { 
                    icon: getIconByZoom('bus', appState.map.getZoom(), lineRef, false, !!nearbyStop), 
                    label: lineRef
                }).addTo(appState.busMarkersLayer);

                appState.buses[itemIdentifier] = {
                    marker, itemIdentifier,
                    lineRef: lineRef,
                    vehicleRef: mvj.getElementsByTagName("VehicleRef")[0]?.textContent || '????',
                    destinationName: mvj.getElementsByTagName("DestinationName")[0]?.textContent || 'N/A',
                    lat: newLat, lon: newLon,
                    lastUpdateTime: recordedAtTime.getTime(),
                    lastPollTime: pollTime,
                    lastMovedTime: pollTime,
                    speedHistory: [], displaySpeed: 0, bearing: bearing,
                    atStopSince: null, currentStopCode: null,
                    isNearStop: !!nearbyStop,
                    isAnimating: false, // Starts stationary
                    nextStopName: null,
                    directionRef: mvj.getElementsByTagName("DirectionRef")[0]?.textContent?.toLowerCase(),
                };

                // Fetch the stop list for this new bus's line and direction
                const directionRef = mvj.getElementsByTagName("DirectionRef")[0]?.textContent?.toLowerCase();
                if (lineRef && directionRef) {
                    // fetchAndParseStopList(lineRef, directionRef); // DISABLED FOR NOW
                }
                
                marker.on('slideend', () => {
                    const bus = appState.buses[itemIdentifier];
                    if (bus) {
                        bus.isAnimating = false;
                        bus.displaySpeed = 0;
                        bus.speedHistory = [];
                    }
                });

                marker.bindPopup('');
                updatePopupContent(appState.buses[itemIdentifier], 'new');
                marker.on('click', () => handleBusClick(itemIdentifier, true));
            }
        });

        for (const key in appState.buses) {
            if (!currentVehicleIds.has(key)) {
                appState.busMarkersLayer.removeLayer(appState.buses[key].marker);
                delete appState.buses[key];
            }
        }
        updateBusList();
    } catch (error) {
        console.error(error);
        showErrorPopup(error);
        ui.statusMessage.textContent = `Updates paused due to error.`;
        if (appState.fetchIntervalId) {
            clearInterval(appState.fetchIntervalId);
            appState.fetchIntervalId = null;
        }
        if (appState.heartbeatIntervalId) {
            clearInterval(appState.heartbeatIntervalId);
            appState.heartbeatIntervalId = null;
        }
    } finally {
        
    }
}

function startStaleBusChecker() {
    const STALE_TIMEOUT_MS = 15000;
    const CHECK_INTERVAL_MS = 2000;

    setInterval(() => {
        const now = Date.now();
        for (const key in appState.buses) {
            const bus = appState.buses[key];
            const timeSinceLastUpdate = now - bus.lastPollTime;

            if (timeSinceLastUpdate > STALE_TIMEOUT_MS) {
                // If the marker is not at its actual last known position, slide it there.
                const currentPos = bus.marker.getLatLng();
                if (getDistance(currentPos.lat, currentPos.lng, bus.lat, bus.lon) > 0.001) {
                     console.log(`Bus ${bus.vehicleRef} is stale. Snapping to actual position.`);
                    bus.marker.slideTo([bus.lat, bus.lon], {
                        duration: 1000 // A gentle slide to the final spot
                    });
                }
            }
        }
    }, CHECK_INTERVAL_MS);
}

function updateBusList() {
    const listFragment = document.createDocumentFragment();
    Object.values(appState.buses).sort((a, b) => a.lineRef.localeCompare(b.lineRef)).forEach(bus => {
        const listItem = document.createElement('li');
        listItem.dataset.id = bus.itemIdentifier;
        listItem.dataset.type = 'bus';
        listItem.dataset.vehicleRef = bus.vehicleRef;
        listItem.innerHTML = `<b>${bus.lineRef}</b> to ${bus.destinationName} (ID: ${bus.vehicleRef.slice(-4)})`;
        listFragment.appendChild(listItem);
    });
    // Clear the list more efficiently
    while (ui.busList.firstChild) {
        ui.busList.removeChild(ui.busList.firstChild);
    }
    ui.busList.appendChild(listFragment);
}

// --- Initialization ---
function startAutoUpdate() {
    if (appState.fetchIntervalId) clearInterval(appState.fetchIntervalId);
    appState.fetchIntervalId = setInterval(fetchData, appState.updateInterval);
}

function init() {
    alert("DEBUG: New script loaded! Version 107.");
    Object.assign(ui, {
        busList: document.getElementById('bus-list'),
        busStopList: document.getElementById('bus-stop-list'),
        busStopToggle: document.getElementById('bus-stop-toggle'),
        statusMessage: document.getElementById('status-message'),
        errorOverlay: document.getElementById('error-overlay'),
        errorMessage: document.getElementById('error-message'),
        copyErrorBtn: document.getElementById('copy-error-btn'),
        closeErrorBtn: document.getElementById('close-error-btn'),
        menuToggle: document.getElementById('menu-toggle'),
        sidebar: document.getElementById('sidebar'),
    });

    initMap();
    
    setupEventListeners();
    fetchBusStops();
    fetchData();
    startAutoUpdate();
    startStaleBusChecker();
}

function setupEventListeners() {
    
    ui.busStopToggle.addEventListener('change', handleMapZoom);
    document.querySelectorAll('.tab-link').forEach(button => {
        button.addEventListener('click', (e) => {
            document.querySelectorAll('.tab-link, .tab-content').forEach(el => el.classList.remove('active'));
            e.target.classList.add('active');
            document.getElementById(e.target.dataset.tab).classList.add('active');
        });
    });
    ui.busList.addEventListener('click', handleListClick);
    ui.busStopList.addEventListener('click', handleListClick);

    ui.closeErrorBtn.addEventListener('click', () => ui.errorOverlay.classList.add('hidden'));
    ui.copyErrorBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(ui.errorMessage.textContent);
        ui.copyErrorBtn.textContent = 'Copied!';
        setTimeout(() => { ui.copyErrorBtn.textContent = 'Copy'; }, 2000);
    });

    ui.menuToggle.addEventListener('click', () => {
        ui.sidebar.classList.toggle('active');
    });
}

document.addEventListener('DOMContentLoaded', init);